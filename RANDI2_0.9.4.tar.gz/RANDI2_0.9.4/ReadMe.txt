Update Instructions:
1. Stop tomcat
2. Backup of the database
3. Remove of the old plugins (jar-files in the plugin folder)
4. Copy the new plugins to the plugin folder
5. Remove the old webapp (e.g. path_to_tomcat/webapps/RANDI2)
6. Copy the new war file to tomcats webapp folder
7. Start tomcat (application shows errors, because the path of the folder for the configuration is not set)
8. Change the path of the configuration folder in the file path_to_tomcat/webapps/RANDI2/WEB-INF/classes/config.properties
9. Restart tomcat


Change Log:
0.9.4:
- connection with OpenClinica
- adaptive randomization algorithm

0.9.3:
- New user interface style
- minimization algorithm
- added the possibility to use responses for the randomization algorithm (database backend and user interface changes) 
- implemented response adaptive randomization algorithm
- new installation procedure
- check during randomization if a subject with equal property values exists (randomization is still possible after confirmation)
 

0.9.2:
- New I18N support (English, German)
- Open-/Closed Trials
- Support for PostgreSQL
- New securtiy functionality: A user is blocked for 15 min after 3 failed logins.
- Additional controles during the randomization process to check if a user is part of a participation site.
- Fixed Bug #19 (User need administrator and the trial create right to add a new trial)
- Fixed Bug #24 (Problem with date constraints)


More information under: http://www.randi2.org/redmine/projects/randi2/wiki


